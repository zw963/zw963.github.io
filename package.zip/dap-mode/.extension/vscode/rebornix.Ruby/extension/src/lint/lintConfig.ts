export class Config
{
	pathToRuby: string = 'ruby';
	pathToBundler: string = 'bundle';
	useBundler: boolean | undefined = undefined;
}


