require 'rails_helper'

RSpec.describe Api::Promotion::PushersController, type: :request do
  it 'POST #expected_organization_and_user_count, 没有 token, 会验证错误' do
    post expected_organization_and_user_count_api_promotion_pushers_path
    expect(response).to have_http_status(200)
    expect(content).to eq(code: 100400, message: 'AuthError', error: 'auth_error')
  end

  it 'POST #expected_organization_and_user_count, 返回期望的企业和用户数量, is_all true' do
    org1 = create(:organization)
    org2 = create(:organization)
    org3 = create(:organization)
    org1_super_admin_role = create(:role, organization: org1, settings: {internal: true}, name: '超级管理员') # 超级用户定义
    org2_super_admin_role = create(:role, organization: org2, settings: {internal: true}, name: '超级管理员') # 超级用户定义
    admin_role = create(:role, organization: org1, name: '普通管理员')
    normal_role1 = create(:role, organization: org1, settings: {})
    normal_role2 = create(:role, organization: org3, settings: {})
    normal_role3 = create(:role, organization: nil, settings: {}) # organization_id is nil, not match.

    user1 = create(:user, role: org1_super_admin_role, organization: org1)
    user2 = create(:user, role: org1_super_admin_role, organization: org1)
    user3 = create(:user, role: org2_super_admin_role, organization: org2)
    user4 = create(:user, role: admin_role, organization: org1)
    user5 = create(:user, role: admin_role, organization: org1)
    user6 = create(:user, role: normal_role1, organization: org1)
    user7 = create(:user, role: normal_role2, organization: org3) # role 的 organization_id 为 nil

    user8 = create(:user, role: normal_role3) # role 的 organization_id 为 nil


    post expected_organization_and_user_count_api_promotion_pushers_path, {
      is_all: 'true',
      role_type: '超级管理员',
      organization_ids: nil
    }, {'ACCESS-TOKEN' => '0sFc4mpJfhCRO3FQ7BqsZTeCsmbylCxdKz44Qd3Zr8UbpLdmoNL0ORRmx-fQa3ZKlS8'}
    expect(response).to have_http_status(200)
    expect(content.code).to eq 0
    expect(content.msg).to eq '获取数据成功'
    expect(content.data.user_count).to eq 3
    expect(content.data.user_ids).to match_array [user1.id, user2.id, user3.id]
    expect(content.data.organization_count).to eq 2
    expect(content.data.organization_ids).to match_array [org1.id, org2.id]

    post expected_organization_and_user_count_api_promotion_pushers_path, {
      is_all: 'true',
      role_type: '普通管理员和超级管理员',
      organization_ids: nil
    }, {'ACCESS-TOKEN' => '0sFc4mpJfhCRO3FQ7BqsZTeCsmbylCxdKz44Qd3Zr8UbpLdmoNL0ORRmx-fQa3ZKlS8'}
    expect(response).to have_http_status(200)
    expect(content.code).to eq 0
    expect(content.msg).to eq '获取数据成功'
    expect(content.data.user_count).to eq 5
    expect(content.data.user_ids).to match_array [user1.id, user2.id, user3.id, user4.id, user5.id]
    expect(content.data.organization_count).to eq 2
    expect(content.data.organization_ids).to match_array [org1.id, org2.id]

    post expected_organization_and_user_count_api_promotion_pushers_path, {
      is_all: 'true',
      role_type: '全部员工',
      organization_ids: nil
    }, {'ACCESS-TOKEN' => '0sFc4mpJfhCRO3FQ7BqsZTeCsmbylCxdKz44Qd3Zr8UbpLdmoNL0ORRmx-fQa3ZKlS8'}
    expect(response).to have_http_status(200)
    expect(content.code).to eq 0
    expect(content.msg).to eq '获取数据成功'
    expect(content.data.user_count).to eq 7
    expect(content.data.organization_count).to eq 3
  end

  it 'POST #expected_organization_and_user_count, 返回期望的企业和用户数量, is_all: false' do
    org1 = create(:organization)
    org2 = create(:organization)
    org3 = create(:organization)
    org1_super_admin_role = create(:role, organization: org1, settings: {internal: true}, name: '超级管理员')
    org2_super_admin_role = create(:role, organization: org2, settings: {internal: true}, name: '超级管理员')
    org3_super_admin_role = create(:role, organization: org3, settings: {internal: true}, name: '超级管理员') # org3 没有传入.
    admin_role = create(:role, organization: org1, name: '普通管理员')
    normal_role = create(:role, organization: org1, settings: {})

    user1 = create(:user, role: org1_super_admin_role, organization: org1)
    user2 = create(:user, role: org1_super_admin_role, organization: org1)
    user3 = create(:user, role: org2_super_admin_role, organization: org2)
    user4 = create(:user, role: org3_super_admin_role, organization: org3) # 这个应该忽略。

    user5 = create(:user, role: admin_role, organization: org1)
    user6 = create(:user, role: admin_role, organization: org1)
    user7 = create(:user, role: normal_role, organization: org1)

    post expected_organization_and_user_count_api_promotion_pushers_path, {
      is_all: 'false',
      role_type: '超级管理员',
      organization_ids: [org1.id, org2.id].to_json
    }, {'ACCESS-TOKEN' => '0sFc4mpJfhCRO3FQ7BqsZTeCsmbylCxdKz44Qd3Zr8UbpLdmoNL0ORRmx-fQa3ZKlS8'}
    expect(response).to have_http_status(200)
    expect(content.code).to eq 0
    expect(content.msg).to eq '获取数据成功'
    expect(content.data.user_count).to eq 3
    expect(content.data.user_ids).to match_array [user1.id, user2.id, user3.id]
    expect(content.data.organization_count).to eq 2
    expect(content.data.organization_ids).to match_array [org1.id, org2.id]

    post expected_organization_and_user_count_api_promotion_pushers_path, {
      is_all: 'false',
      role_type: '普通管理员和超级管理员',
      organization_ids: [org1.id, org2.id].to_json
    }, {'ACCESS-TOKEN' => '0sFc4mpJfhCRO3FQ7BqsZTeCsmbylCxdKz44Qd3Zr8UbpLdmoNL0ORRmx-fQa3ZKlS8'}
    expect(response).to have_http_status(200)
    expect(content.code).to eq 0
    expect(content.msg).to eq '获取数据成功'
    expect(content.data.user_count).to eq 5
    expect(content.data.user_ids).to match_array [user1.id, user2.id, user3.id, user5.id, user6.id]
    expect(content.data.organization_count).to eq 2
    expect(content.data.organization_ids).to match_array [org1.id, org2.id]

    post expected_organization_and_user_count_api_promotion_pushers_path, {
      is_all: 'false',
      role_type: '全部员工',
      organization_ids: [org1.id, org2.id].to_json
    }, {'ACCESS-TOKEN' => '0sFc4mpJfhCRO3FQ7BqsZTeCsmbylCxdKz44Qd3Zr8UbpLdmoNL0ORRmx-fQa3ZKlS8'}
    expect(response).to have_http_status(200)
    expect(content.code).to eq 0
    expect(content.msg).to eq '获取数据成功'
    expect(content.data.user_count).to eq 6
    expect(content.data.user_ids).to match_array [user1.id, user2.id, user3.id, user5.id, user6.id, user7.id]
    expect(content.data.organization_count).to eq 2
    expect(content.data.organization_ids).to match_array [org1.id, org2.id]
  end

  describe 'POST #cms_pusher' do
    # it 'CMS通知 CRM 去更新 pusher 内容, 并推送消息，全部企业' do
#       org1 = create(:organization, id: 1)
#       org2 = create(:organization, id: 2)
#       org3 = create(:organization, id: 3)
#       role1 = create(:role, organization: org1, name: '超级管理员', settings: {internal: true})
#       role2 = create(:role, organization: org2, name: '普通管理员')
#       role3 = create(:role, organization: org3, name: '普通管理员')

#       user1 = create(:user, organization: org1, role: role1, id: 1)
#       user2 = create(:user, organization: org2, role: role2, id: 2)
#       user3 = create(:user, organization: org2, role: role2, id: 3)
#       user4 = create(:user, organization: org3, role: role3, id: 4)
#       user5 = create(:user, organization: org3, role: role3, id: 5)

#       post cms_pusher_api_promotion_pushers_path(pusher_id: 1)
#       assert_response :success
#       expect(content).to eq code: 0, msg: '数据传递成功'

#       VCR.use_cassette('update_cms_pushser_content_is_all', :serialize_with =>  :yaml) do
#         expect { CmsPusherWorker.drain }.to output("\033[0;33msend pusher, cmsid: 1\033[0m
# \033[0;33muser ids: [1, 2, 3, 4, 5]\033[0m
# 发送 lixiao 文本卡片 参数链接 1!
# 发送 lixiao 文本卡片 参数链接 2!
# 发送 lixiao 文本卡片 参数链接 3!
# 发送 lixiao 文本卡片 参数链接 4!
# 发送 lixiao 文本卡片 参数链接 5!\n").to_stderr
#       end
#     end

    it 'CMS通知 CRM 去更新 pusher 内容, 并推送消息，全部企业, 图文消息' do
      org1 = create(:organization, id: 1)
      org2 = create(:organization, id: 2)
      org3 = create(:organization, id: 3)
      role1 = create(:role, organization: org1, name: '超级管理员', settings: {internal: true})
      role2 = create(:role, organization: org2, name: '普通管理员')
      role3 = create(:role, organization: org3, name: '普通管理员')

      user1 = create(:user, :with_ding_user, organization: org1, role: role1, id: 1)
      user2 = create(:user, :with_ding_user, organization: org2, role: role2, id: 2)
      user3 = create(:user, :with_ding_user, organization: org2, role: role2, id: 3)

      ding_user1 = user1.ding_user
      ding_user2 = user2.ding_user
      ding_user3 = user3.ding_user

      ding_org1 = ding_user1.ding_organization
      ding_org2 = ding_user2.ding_organization
      ding_org3 = ding_user3.ding_organization

      ding_suite1 = create(:ding_suite)
      ding_suite2 = create(:ding_suite)
      ding_suite3 = create(:ding_suite)

      create(:ding_suite_subscriber, ding_suite: ding_suite1, ding_organization: ding_org1)
      create(:ding_suite_subscriber, ding_suite: ding_suite2, ding_organization: ding_org2)
      create(:ding_suite_subscriber, ding_suite: ding_suite3, ding_organization: ding_org3)

      ding_suite1.ding_agents << create(:ding_agent, ding_app: ding_suite1.ding_app, ding_organization: ding_org1)
      ding_suite2.ding_agents << create(:ding_agent, ding_app: ding_suite2.ding_app, ding_organization: ding_org2)
      ding_suite3.ding_agents << create(:ding_agent, ding_app: ding_suite3.ding_app, ding_organization: ding_org3)

      post cms_pusher_api_promotion_pushers_path(pusher_id: 1)
      assert_response :success
      expect(content).to eq code: 0, msg: '数据传递成功'

      VCR.use_cassette('update_cms_pushser_content_is_all_tuwen_xiaoxi') do
        expect { CmsPusherWorker.drain }.to output("\033[0;33msend pusher, cmsid: 1\033[0m
\033[0;33muser ids: [1, 2, 3]\033[0m
发送 dingding 图文消息 参数链接 1!
发送 dingding 图文消息 参数链接 2!
发送 dingding 图文消息 参数链接 3!\n").to_stderr
      end
    end

    # it 'CMS通知 CRM 去更新 pusher 内容, 并推送消息，部分企业.' do
#       org1 = create(:organization, id: 1)
#       org2 = create(:organization, id: 2)
#       org3 = create(:organization, id: 3)
#       org4 = create(:organization, id: 4)
#       role1 = create(:role, organization: org1, name: '超级管理员', settings: {internal: true})
#       role2 = create(:role, organization: org2, name: '普通管理员')
#       role3 = create(:role, organization: org3, name: '普通管理员')
#       role4 = create(:role, organization: org4, name: '普通管理员')

#       user1 = create(:user, organization: org1, role: role1, id: 1)
#       user2 = create(:user, organization: org2, role: role2, id: 2)
#       user3 = create(:user, organization: org2, role: role2, id: 3)
#       user4 = create(:user, organization: org3, role: role3, id: 4)
#       user5 = create(:user, organization: org3, role: role3, id: 5)
#       user6 = create(:user, organization: org4, role: role4, id: 6)

#       post cms_pusher_api_promotion_pushers_path(pusher_id: 1)
#       assert_response :success
#       expect(content).to eq code: 0, msg: '数据传递成功'

#       VCR.use_cassette('update_cms_pushser_content_not_is_all', :serialize_with =>  :yaml) do
#         expect { CmsPusherWorker.drain }.to output("\033[0;33msend pusher, cmsid: 1\033[0m
# \033[0;33muser ids: [1, 2, 3, 4, 5, 6]\033[0m
# 发送 lixiao 文本卡片 普通链接 1!
# 发送 lixiao 文本卡片 普通链接 2!
# 发送 lixiao 文本卡片 普通链接 3!
# 发送 lixiao 文本卡片 普通链接 4!
# 发送 lixiao 文本卡片 普通链接 5!
# 发送 lixiao 文本卡片 普通链接 6!\n").to_stderr
#       end
#     end
  end

  describe 'POST #user_show_behavior' do
    it '请求 CMS pusher API, 被推送的用户计数+1, 成功' do
      user = create(:user)
      VCR.use_cassette('post_cms_pusher_to_create_show_count', :serialize_with =>  :yaml) do
        post user_show_behavior_api_promotion_pushers_path(pusher_id: 1, user_id: user.id)
      end
      assert_response :success
      expect(content).to eq code: 0, msg: '记录推送成功'
    end

    it 'POST #user_show_behavior, 请求 CMS pusher API, 被推送的用户计数+1, 失败' do
      post user_show_behavior_api_promotion_pushers_path(pusher_id: 1, user_id: nil)
      assert_response :success
      expect(content).to eq code: 0, msg: '缺少参数'
    end

    it 'POST #user_show_behavior, 请求 CMS pusher API, 被推送的用户计数+1, 失败' do
      user = create(:user)
      post user_show_behavior_api_promotion_pushers_path(pusher_id: nil, user_id: user.id)
      assert_response :success
      expect(content).to eq code: 0, msg: '缺少参数'
    end
  end

  describe 'POST #user_click_behavior' do
    it '请求 CMS pusher API, 推送用户点击+1, 成功' do
      user = create(:user)
      VCR.use_cassette('post_cms_pusher_to_create_click_count', :serialize_with =>  :yaml) do
        post user_click_behavior_api_promotion_pushers_path(pusher_id: 1, user_id: user.id)
      end
      assert_response :success
      expect(content).to eq code: 0, msg: '记录推送成功'
    end

    it '请求 CMS pusher API, 推送用户点击+1, 失败' do
      VCR.use_cassette('post_cms_pusher_to_create_click_count', :serialize_with =>  :yaml) do
        post user_click_behavior_api_promotion_pushers_path(pusher_id: 1, user_id: nil)
      end
      assert_response :success
      expect(content).to eq code: 0, msg: '缺少参数'
    end

    it '请求 CMS pusher API, 推送用户点击+1, 失败' do
      user = create(:user)
      VCR.use_cassette('post_cms_pusher_to_create_click_count', :serialize_with =>  :yaml) do
        post user_click_behavior_api_promotion_pushers_path(pusher_id: nil, user_id: user.id)
      end
      assert_response :success
      expect(content).to eq code: 0, msg: '缺少参数'
    end
  end
end
