class AddServeCountPerDayToTenants < ActiveRecord::Migration
  def change
    add_column :tenants, :serve_count_per_day, :integer, default: 0
  end
end
