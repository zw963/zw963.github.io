class AddLastServeAtToTenants < ActiveRecord::Migration
  def change
    add_column :tenants, :last_serve_at, :datetime
  end
end
