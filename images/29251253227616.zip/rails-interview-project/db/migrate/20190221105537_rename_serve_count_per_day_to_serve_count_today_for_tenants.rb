class RenameServeCountPerDayToServeCountTodayForTenants < ActiveRecord::Migration
  def change
    rename_column :tenants, :serve_count_per_day, :serve_count_today
  end
end
