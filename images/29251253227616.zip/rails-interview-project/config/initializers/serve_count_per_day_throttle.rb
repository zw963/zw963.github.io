class ServeCountPerDayThrottle
  def initialize(app)
    @app = app
  end

  def call(env)
    request = Rack::Request.new(env)
    consumer = Tenant.find_by(api_key: request.params['api_key'])

    forbidden_res = [403, {'ContentType' => 'appliation/json'}, [{msg: 'forbidden'}.to_json]]

    return forbidden_res if consumer.nil?

    if consumer.serve_count_today > 100 &&
        (Time.current - consumer.last_serve_at).truncate < 10
      forbidden_res
    else
      @app.call(env)
    end
  end
end

Rails.application.middleware.use ServeCountPerDayThrottle
