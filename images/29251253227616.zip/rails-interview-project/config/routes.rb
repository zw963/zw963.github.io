Rails.application.routes.draw do
  root 'home#index'

  get 'welcome' => 'welcome#index'
  resources :question_with_answers, only: [:index]
end
