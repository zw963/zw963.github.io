FactoryBot.define do
  factory :question do
    title
    user
  end

  factory :answer do
    body 'body content'
    question
    user
  end

  factory :user do
    name
  end

  factory :tenant do
    name
  end

  @base58_alphabet = ('0'..'9').to_a + ('A'..'Z').to_a + ('a'..'z').to_a - ['0', 'O', 'I', 'l']

  def base58(n=5)
    SecureRandom.random_bytes(n).unpack('C*').map do |byte|
      idx = byte % 64
      idx = SecureRandom.random_number(58) if idx >= 58
      @base58_alphabet[idx]
    end.join
  end

  sequence(:title) {|n| "title_#{base58(5)}#{n}" }
  sequence(:name) {|n| "name_#{base58(5)}#{n}" }
end
