class QuestionWithAnswersControllerTest < ActionController::TestCase
  test "index should return public question with answers" do
    consumer1 = create(:tenant)
    consumer2 = create(:tenant)

    asker1 = create(:user)
    asker2 = create(:user)
    provider1 = create(:user)
    provider2 = create(:user)
    provider3 = create(:user)

    question1 = create(:question, user: asker1)
    answer1 = create(:answer, question: question1, user: provider1)
    answer2 = create(:answer, question: question1, user: provider2)
    answer3 = create(:answer, question: question1, user: provider3)

    question2 = create(:question, private: true)
    create(:answer, question: question2, user: provider1)
    create(:answer, question: question2, user: provider2)

    question3 = create(:question, user: asker2)
    answer4 = create(:answer, question: question3, user: provider1)
    answer5 = create(:answer, question: question3, user: provider2)

    get :index, format: :json, api_key: consumer1.api_key

    assert_response :success
    assert_equal '200', content.code
    assert_equal 'ok', content.msg

    questions = content.data.questions
    # assert_equal 2, questions.size
    assert_equal [question1, question3].map(&:id), questions.map {|e| e[:id] }
    assert_equal [question1, question3].map(&:title), questions.map {|e| e[:title] }

    result_question1, result_question2 = questions

    assert_equal([
      {
        body: answer1.body,
        user: {
          name: provider1.name
        }
      },
      {
        body: answer2.body,
        user: {
          name: provider2.name
        }
      },
      {
        body: answer3.body,
        user: {
          name: provider3.name
        }
      }
    ], result_question1[:answers])

    assert_equal([
      {
        body: answer4.body,
        user: {
          name: provider1.name
        }
      },
      {
        body: answer5.body,
        user: {
          name: provider2.name
        }
      }
    ], result_question2[:answers])
  end

  test 'invalid api_key will response 403' do
    consumer1 = create(:tenant)

    get :index, format: :json, api_key: consumer1.api_key.succ
    assert_response :forbidden
    assert_equal 'forbidden', content.msg
  end

  test 'increment serve_count_today per request per day' do
    consumer1 = create(:tenant)

    assert_equal 0, consumer1.serve_count_today
    assert_nil consumer1.last_serve_at

    travel_to '2019-02-21 10:20:15 UTC'
    get :index, format: :json, api_key: consumer1.api_key

    consumer1.reload
    assert_equal 1, consumer1.serve_count_today
    assert_equal '2019-02-21 10:20:15 UTC', consumer1.last_serve_at.to_s

    travel_to '2019-02-21 15:20:15 UTC'
    get :index, format: :json, api_key: consumer1.api_key
    consumer1.reload
    assert_equal 2, consumer1.serve_count_today
    assert_equal '2019-02-21 15:20:15 UTC', consumer1.last_serve_at.to_s

    travel_to '2019-02-21 16:20:15 UTC'
    get :index, format: :json, api_key: consumer1.api_key
    consumer1.reload
    assert_equal 3, consumer1.serve_count_today
    assert_equal '2019-02-21 16:20:15 UTC', consumer1.last_serve_at.to_s
    travel_back
  end

  test "index should response public question with answers which match query string" do
    consumer1 = create(:tenant)

    asker1 = create(:user)
    provider1 = create(:user)
    provider2 = create(:user)
    provider3 = create(:user)

    question1 = create(:question, user: asker1, title: 'question1')
    answer1 = create(:answer, question: question1, user: provider1)
    answer2 = create(:answer, question: question1, user: provider2)
    answer3 = create(:answer, question: question1, user: provider3)

    question2 = create(:question, user: asker1, title: 'another title')
    create(:answer, question: question2, user: provider1)
    create(:answer, question: question2, user: provider2)

    question3 = create(:question, user: asker1, title: 'question3')
    answer4 = create(:answer, question: question3, user: provider1)
    answer5 = create(:answer, question: question3, user: provider2)

    get :index, format: :json, api_key: consumer1.api_key

    assert_response :success
    assert_equal '200', content.code
    assert_equal 'ok', content.msg

    questions = content.data.questions
    assert_equal 3, questions.size

    get :index, format: :json, api_key: consumer1.api_key, query: 'question'

    assert_response :success
    assert_equal '200', content.code
    assert_equal 'ok', content.msg

    questions = content.data.questions
    assert_equal 2, questions.size
  end
end
