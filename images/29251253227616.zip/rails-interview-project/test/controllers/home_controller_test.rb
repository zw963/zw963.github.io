class HomeControllerTest < ActionController::TestCase
  test "index should return public question with answers" do
    consumer1 = create(:tenant, serve_count_today: 25)
    consumer2 = create(:tenant, serve_count_today: 40)

    asker1 = create(:user)
    asker2 = create(:user)
    provider1 = create(:user)
    provider2 = create(:user)
    provider3 = create(:user)

    question1 = create(:question, user: asker1)
    answer1 = create(:answer, question: question1, user: provider1)
    answer2 = create(:answer, question: question1, user: provider2)
    answer3 = create(:answer, question: question1, user: provider3)

    question2 = create(:question, private: true, user: asker1)
    create(:answer, question: question2, user: provider1)
    create(:answer, question: question2, user: provider2)

    question3 = create(:question, user: asker2)
    answer4 = create(:answer, question: question3, user: provider1)
    answer5 = create(:answer, question: question3, user: provider2)

    get :index

    assert_response :success

    assert_equal 5, assigns(:user_count)
    assert_equal 3, assigns(:question_count)
    assert_equal 7, assigns(:answer_count)
    assert_equal 65, assigns(:tenant_serve_count)
  end
end
