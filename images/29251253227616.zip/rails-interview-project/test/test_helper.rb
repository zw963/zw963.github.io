ENV['RAILS_ENV'] ||= 'test'
require File.expand_path('../../config/environment', __FILE__)
require 'rails/test_help'

class ActiveSupport::TestCase
  include ActiveSupport::Testing::TimeHelpers
  include FactoryBot::Syntax::Methods

  def content
    res = JSON.parse(response.body)

    if res.is_a? Array
      res.map { |e| Hashr.new(e) }
    else
      Hashr.new(res)
    end
  rescue JSON::ParserError
    response.body
  end
end
