class HomeController < ApplicationController
  def index
    @user_count = User.count
    @question_count = Question.count
    @answer_count = Answer.count
    @tenant_serve_count = Tenant.select("sum(serve_count_today) as count").last['count']
  end
end
