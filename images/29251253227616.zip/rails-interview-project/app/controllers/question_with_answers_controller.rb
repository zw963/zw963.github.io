class QuestionWithAnswersController < ApplicationController
  def index
    api_key = params[:api_key]
    keyword = params[:query]

    consumer = Tenant.find_by(api_key: api_key)

    if consumer
      if consumer.last_serve_at && consumer.last_serve_at.today?
        consumer.increment(:serve_count_today)
      else
        consumer.serve_count_today = 1
      end

      consumer.last_serve_at = Time.current
      consumer.save

      @questions = Question.includes(answers: [:user]).visible.title_match(keyword).distinct
    else
      render json: {msg: 'forbidden'}, status: :forbidden
    end
  end
end
