class Question < ActiveRecord::Base

  has_many :answers
  belongs_to :user

  scope :visible, -> { where(private: false) }

  scope :title_match, ->(keyword) do
    if keyword.blank?
      all
    else
      where("questions.title LIKE ?", "%#{keyword}%")
    end
  end
end
