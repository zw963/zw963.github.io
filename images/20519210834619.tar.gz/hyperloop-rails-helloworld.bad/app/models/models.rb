require_tree './public' if RUBY_ENGINE == 'opal'
