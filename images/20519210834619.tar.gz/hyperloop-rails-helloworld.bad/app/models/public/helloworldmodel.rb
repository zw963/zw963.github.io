class Helloworldmodel < ApplicationRecord
end
