class HomeController < ApplicationController
  def helloworld

  end
end
