
Hyperloop.configuration do |config|
  config.transport = :action_cable
end
