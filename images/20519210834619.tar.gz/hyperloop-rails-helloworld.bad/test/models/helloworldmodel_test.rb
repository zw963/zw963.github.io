require 'test_helper'

class HelloworldmodelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
