require 'test_helper'

class HomeControllerTest < ActionDispatch::IntegrationTest
  test '#helloworld' do

  end
end
